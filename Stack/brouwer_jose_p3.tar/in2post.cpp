//Name: Jose Brouwer
#include "stack.h"
#include <string>
#include <cctype>

using namespace std;
using namespace cop4530;

bool lower(char c, Stack<char>& stk) //check for lower precedence
{
  if((c == '*' || c == '/') && (stk.top() == '+' || stk.top() == '-'))
    return true;
  return false;
}
bool isOperator(char c)
{
  if(c == '+' || c == '-' || c == '*' || c == '/')
    return true;
  return false;
}
void printTop(string& s, Stack<char>& stk) //repeatedly print top of stack
{
  s += stk.top();
  s += ' '; //print top of the stack
  stk.pop(); //pop stack
}

string toPost(string s) //convert to postfix expression
{
  Stack<char> post; //char stack to hold operators
  string conv;
  auto itr = s.begin(); //iterator to move through string
  int i = 0;
  for(; itr != s.end(); itr++) //go thorugh string
  {
    if(*itr == '(')
      post.push(*itr);
    else if(isOperator(*itr))
    {
      while(!(post.empty()) && !(post.top() == '(') || lower(*itr, post))
        printTop(conv, post);
      post.push(*itr);
    }
    else if(*itr == ')' && isOperator(s[i - 2]))
      cout << "There was an issue with your operators..." << endl;
    else if(*itr == ')')
    {
      while(!(post.top() == '('))
        printTop(conv, post);
      post.pop(); //discard '('
    }
    else if(!(isOperator(*itr)) && !(isspace(*itr)))
    {
      if(!(isspace(s[i+1])) && !(s[i+1] == '\0'))
        conv += *itr;
      else
      {
        conv += *itr;
        conv += ' ';
      }
    }
    i++; //to know index
  }//end for
  if((itr == s.end()) && ((*itr) == '('))
  {
    cout << "\nEnd of input reached... Last operator processed was ( ..." << endl;
    return '\0';
  }
  else
  {
    while(!(post.empty()))
    {
      if(post.top() == '(')
      {
        cout << "end of input was reached and a ( was found while printing..." << endl;
        return '\0';
      }
      printTop(conv, post);
    }
  }
  return conv;
}

void evaluate(string s)
{
  Stack<double> operand;
  std::string num;
  int i = 0;
  int counter = 0;
  auto itr = s.begin();
  for(; itr != s.end(); itr++)
  {
    if(!(isOperator(*itr)) && !(isspace(*itr)) && !(isalpha(*itr)))
    {
      while(!(isspace(s[i+1])))
      {
        num += s[i];
        counter++;
        itr++;
        i++;
      }
      num += s[i];
      counter++;
      itr++;
      i++;
      operand.push(std::stod(num));
      num.clear();
      //cout << "top is: " << operand.top() << endl;
    }
    else if(isOperator(*itr) && (operand.size() >= 2))
    {
      double x = operand.top();
      operand.pop();
      double y = operand.top();
      operand.pop();
      double result;
      if(*itr == '+')
        result = y + x;
      else if(*itr == '-')
        result = y - x;
      else if(*itr == '*')
        result = y * x;
      else if(*itr == '/')
        result = y / x;
      operand.push(result);
    }
    else if(isalpha(*itr))
    {
      cout << "Postfix evaluation: " << s << " = " << s << endl;
      return;
    }
    else if(isOperator(*itr) && (operand.size() < 2))
      cout << "ERROR: There are less than two operands to operate on..." << endl;
    i++;
  }
  if(itr == s.end() && (operand.size() > 1))
    cout << "ERROR: End of input reached with leftover operands..." << endl;
  else if(itr == s.end() && (operand.size() == 1))
    cout << "Postfix evaluation: " << s << " = " << operand.top() << endl;
  else if(itr == s.end() && operand.empty())
    cout << 0 << endl;
}

int main()
{
  string expression;
  cout << "Enter infix expression (""exit"" to quit):";
  getline(cin , expression);
  while(expression != "exit")
  {
    string translated = toPost(expression);
    cout << "Postfix expression: " << translated << endl;
    evaluate(translated);
    cout << "Enter infix expression (""exit"" to quit):";
    getline(cin , expression);
  }
}
